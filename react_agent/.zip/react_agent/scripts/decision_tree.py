#!/usr/bin/env python

class: Decision_tree:
	def __innit__(self):
		pass
	
	def update(distances, where_is_human, how_far_is_human, ): # this takes all inputs from all sensors etc.
		state_var = 0
		if (state_var) = 0:
			if where_is_human = NONE || how_far_is_human = NONE:
				state_var = 1
			if d_sensor[] < d_threshold:
				state_var = 2
		 
		elif(state_var) = 1:
		
		elif(state_var) = 2:
		
		elif(state_var) = 3:
		
		elif(state_var) = 4:
			
		else:
			pass
		
